from django.shortcuts import render

# Create your views here.

from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse, HttpResponseBadRequest
from .models import Game, Score
from django.urls import reverse


def game_list(request):
    games = Game.objects.all()
    return render(request, 'games/game_list.html', {'games': games})
def game_score(request):
    games = Game.objects.all()
    game_data = []

    for game in games:
        top_scores = Score.objects.filter(game=game).select_related('user').order_by('-score')[:5]
        game_data.append({
            'game': game,
            'top_scores': top_scores
        })

    return render(request, 'games/game_score.html', {
        'game_data': game_data
    })
def game_description(request):
    games = Game.objects.all()
    return render(request, 'games/game_description.html', {'games': games})

def game_detail(request, game_id):
    game = get_object_or_404(Game, pk=game_id)
    top_scores = Score.objects.filter(game=game).select_related('user')[:10]
    context = {
        'game': game,
        'top_scores': top_scores,
    }
    return render(request, 'games/game_detail.html', context)

@login_required
def submit_score(request):
    if request.method == 'POST' and request.user.is_authenticated:
        game_id = request.POST.get('game_id')
        score_val = request.POST.get('score')

        try:
            game = Game.objects.get(pk=game_id)
            score_val = int(score_val)
        except (Game.DoesNotExist, ValueError):
            return HttpResponseBadRequest("Invalid game or score")

        # Lower score is better
        existing_score = Score.objects.filter(user=request.user, game=game).first()
        if existing_score:
            if score_val < existing_score.score:
                existing_score.score = score_val
                existing_score.save()
        else:
            Score.objects.create(user=request.user, game=game, score=score_val)

        return redirect(reverse('games:game_detail', args=[game_id]))

    return HttpResponseBadRequest("Invalid request method")