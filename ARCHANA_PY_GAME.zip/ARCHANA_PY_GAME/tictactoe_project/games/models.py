


from django.db import models
from django.contrib.auth.models import User

class Game(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    # We could optionally store which JS/CSS file to use for this game:
    html_file = models.CharField(max_length=200, blank=True)
    js_file = models.CharField(max_length=200, blank=True)
    css_file = models.CharField(max_length=200, blank=True)
    image = models.ImageField(upload_to='images/', blank=True, null=True)  # ✅ add this
    def __str__(self):
        return self.name

class Score(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    game = models.ForeignKey(Game, on_delete=models.CASCADE, related_name='scores')
    score = models.IntegerField()
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-score']  # highest first

    def __str__(self):
        return f"{self.user.username} — {self.score} for {self.game.name}"
