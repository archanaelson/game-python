from django.contrib.auth.models import User
from django.core.cache import cache
from django.utils.timezone import now, timedelta

def get_online_users():
    online_users = []
    for user in User.objects.all():
        last_active = cache.get(f'active_user_{user.pk}')
        if last_active and (now() - last_active) < timedelta(minutes=5):
            online_users.append(user)
    return online_users
