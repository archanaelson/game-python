const canvas = document.getElementById("gameCanvas");
    const ctx = canvas.getContext("2d");
    const scoreEl = document.getElementById("score");
    const gameOverMsg = document.getElementById("gameOverMsg");
    const restartBtn = document.getElementById("restartBtn");
   
    const box = 20;
    let snake;
    let direction;
    let food;
    let score;
    let gameLoop;

    function init() {
      snake = [{ x: 9 * box, y: 10 * box }];
      direction = "RIGHT";
      score = 0;
      scoreEl.innerText = "Score: " + score;
      gameOverMsg.style.display = "none";
      restartBtn.style.display = "none";
      placeFood();
      clearInterval(gameLoop);
      gameLoop = setInterval(drawGame, 100);
    }

    function placeFood() {
      food = {
        x: Math.floor(Math.random() * (canvas.width / box)) * box,
        y: Math.floor(Math.random() * (canvas.height / box)) * box
      };
    }

    function drawGame() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Draw Snake
      for (let i = 0; i < snake.length; i++) {
        ctx.fillStyle = i === 0 ? "#0f0" : "#060";
        ctx.fillRect(snake[i].x, snake[i].y, box, box);
      }

      // Draw Food
      ctx.fillStyle = "#f00";
      ctx.fillRect(food.x, food.y, box, box);

      // Move Snake
      let headX = snake[0].x;
      let headY = snake[0].y;

      if (direction === "LEFT") headX -= box;
      if (direction === "RIGHT") headX += box;
      if (direction === "UP") headY -= box;
      if (direction === "DOWN") headY += box;

      // Check wall collision
      if (
        headX < 0 || headX >= canvas.width ||
        headY < 0 || headY >= canvas.height ||
        isColliding({ x: headX, y: headY }, snake)
      ) {
        gameOver();
        return;
      }

      let newHead = { x: headX, y: headY };

      // Eat food
      if (headX === food.x && headY === food.y) {
        score++;
        scoreEl.innerText = "Score: " + score;
        placeFood();
      } else {
        snake.pop(); // Remove tail
      }

      snake.unshift(newHead); // Add new head
    }

    function isColliding(head, array) {
      return array.some(segment => segment.x === head.x && segment.y === head.y);
    }

    function gameOver() {
      clearInterval(gameLoop);
      gameOverMsg.style.display = "block";
      restartBtn.style.display = "inline-block";
    
      // Submit score
      const scoreInput = document.getElementById("scoreInput");
      scoreInput.value = score;
    
      const scoreForm = document.getElementById("scoreForm");
      if (scoreForm) {
        scoreForm.submit(); // auto-submit score
      }
    }
    

    document.addEventListener("keydown", (e) => {
      if (e.key === "ArrowLeft" && direction !== "RIGHT") direction = "LEFT";
      else if (e.key === "ArrowUp" && direction !== "DOWN") direction = "UP";
      else if (e.key === "ArrowRight" && direction !== "LEFT") direction = "RIGHT";
      else if (e.key === "ArrowDown" && direction !== "UP") direction = "DOWN";
    });

    restartBtn.addEventListener("click", init);

    window.onload = init;