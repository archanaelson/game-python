const scoreEl = document.getElementById("score");
    const timerEl = document.getElementById("timer");
    const target = document.getElementById("target");
    const gameArea = document.getElementById("gameArea");
    const gameOverMsg = document.getElementById("gameOverMsg");
    const restartBtn = document.getElementById("restartBtn");

    let score = 0;
    let timeLeft = 30;
    let countdownInterval;
    let fallInterval;
    let fallSpeed = 2;
    let targetY = 0;
    let targetX = 0;

    function dropTarget() {
      targetY += fallSpeed;
      target.style.top = targetY + "px";

      if (targetY > gameArea.clientHeight - target.clientHeight) {
        endGame();
      }
    }

    function resetTarget() {
      targetY = 0;
      targetX = Math.floor(Math.random() * (gameArea.clientWidth - target.clientWidth));
      target.style.left = targetX + "px";
      target.style.top = targetY + "px";
    }

    function startGame() {
      // Reset
      score = 0;
      timeLeft = 30;
      scoreEl.innerText = "Score: " + score;
      timerEl.innerText = "Time: " + timeLeft;
      gameOverMsg.style.display = "none";
      restartBtn.style.display = "none";
      target.style.display = "block";

      resetTarget();

      // Start falling
      fallInterval = setInterval(() => {
        dropTarget();
      }, 30); // controls how smooth it falls

      // Timer countdown
      countdownInterval = setInterval(() => {
        timeLeft--;
        timerEl.innerText = "Time: " + timeLeft;

        if (timeLeft <= 0) {
          endGame();
        }
      }, 1000);
    }

    function endGame() {
      clearInterval(fallInterval);
      clearInterval(countdownInterval);
      target.style.display = "none";
      gameOverMsg.style.display = "block";
      restartBtn.style.display = "inline-block";
    
      // Update hidden input value with score
      const scoreInput = document.getElementById("scoreInput");
      if (scoreInput) {
        scoreInput.value = score;
      }
    
      // Show the submit score button (if user is logged in)
      const submitBtn = document.getElementById("submitScoreBtn");
      if (submitBtn) {
        submitBtn.style.display = "inline-block";
      }
    }
    

    target.addEventListener("click", () => {
      score++;
      scoreEl.innerText = "Score: " + score;
      resetTarget();
    });

    restartBtn.addEventListener("click", startGame);

    // Start game on load
    window.onload = startGame;