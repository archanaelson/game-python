const scoreEl = document.getElementById("score");
const timerEl = document.getElementById("timer");
const target = document.getElementById("target");
const gameArea = document.getElementById("gameArea");
const gameOverMsg = document.getElementById("gameOverMsg");
const restartBtn = document.getElementById("restartBtn");

let score = 0;
let timeLeft = 30;
let countdownInterval;
let moveInterval;

function moveTarget() {
  const maxX = gameArea.clientWidth - target.clientWidth;
  const maxY = gameArea.clientHeight - target.clientHeight;

  const randomX = Math.floor(Math.random() * maxX);
  const randomY = Math.floor(Math.random() * maxY);

  target.style.left = randomX + "px";
  target.style.top = randomY + "px";
}

function startGame() {
  score = 0;
  timeLeft = 30;
  scoreEl.textContent = "Score: " + score;
  timerEl.textContent = "Time: " + timeLeft;
  gameOverMsg.style.display = "none";
  restartBtn.style.display = "none";
  target.style.display = "block";

  moveTarget();

  moveInterval = setInterval(moveTarget, 800);

  countdownInterval = setInterval(() => {
    timeLeft--;
    timerEl.textContent = "Time: " + timeLeft;

    if (timeLeft <= 0) {
      endGame();
    }
  }, 1000);
}

function endGame() {
  clearInterval(moveInterval);
  clearInterval(countdownInterval);
  target.style.display = "none";
  gameOverMsg.style.display = "block";
  restartBtn.style.display = "inline-block";

  // Submit score to Django form
  const scoreInput = document.getElementById("scoreInput");
  if (scoreInput) {
    scoreInput.value = score;
  }

  const form = document.getElementById("scoreForm");
  if (form) {
    form.submit(); // Automatically submit score after game ends
  }
}


target.addEventListener("click", () => {
  score++;
  scoreEl.textContent = "Score: " + score;
  moveTarget();
});

restartBtn.addEventListener("click", startGame);

window.onload = startGame;