const gameBoard = document.getElementById("gameBoard");
const statusEl = document.getElementById("status");
const restartBtn = document.getElementById("restartBtn");
const scoreEl = document.getElementById("score");

let firstCard = null;
let secondCard = null;
let lockBoard = false;
let matchedPairs = 0;
let score = 0;

function generateShuffledNumbers() {
  const numbers = [];
  for (let i = 1; i <= 8; i++) {
    numbers.push(i);
    numbers.push(i);
  }
  return numbers.sort(() => Math.random() - 0.5);
}

function createCard(number) {
  const card = document.createElement("div");
  card.classList.add("card", "hidden");
  card.dataset.number = number;
  card.textContent = number;

  card.addEventListener("click", () => {
    if (lockBoard || card.classList.contains("matched") || card === firstCard) return;

    card.classList.remove("hidden");

    if (!firstCard) {
      firstCard = card;
    } else {
      secondCard = card;
      lockBoard = true;
      score++;
      scoreEl.textContent = "Score: " + score;

      if (firstCard.dataset.number === secondCard.dataset.number) {
        firstCard.classList.add("matched");
        secondCard.classList.add("matched");
        matchedPairs++;

        if (matchedPairs === 8) {
          statusEl.textContent = "🎉 All pairs matched!";
          restartBtn.style.display = "inline-block";

          // Submit score to Django form
          const scoreInput = document.getElementById("scoreInput");
          if (scoreInput) scoreInput.value = score;

          const form = document.getElementById("scoreForm");
          if (form) form.submit();  // Auto-submit score
        }

        resetTurn();
      } else {
        setTimeout(() => {
          firstCard.classList.add("hidden");
          secondCard.classList.add("hidden");
          resetTurn();
        }, 1000);
      }
    }
  });

  return card;
}

function resetTurn() {
  firstCard = null;
  secondCard = null;
  lockBoard = false;
}

function startGame() {
  gameBoard.innerHTML = "";
  statusEl.textContent = "";
  restartBtn.style.display = "none";
  matchedPairs = 0;
  score = 0;
  scoreEl.textContent = "Score: 0";

  const shuffled = generateShuffledNumbers();
  shuffled.forEach(num => {
    const card = createCard(num);
    gameBoard.appendChild(card);
  });
}

restartBtn.addEventListener("click", startGame);
window.onload = startGame;
