const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const scoreEl = document.getElementById('score');
const restartBtn = document.getElementById('restartBtn');

let score = 0;
const letters = [];
const maxLetters = 40;
const spawnInterval = 300;

// === Letter Class ===
class FlyingLetter {
  constructor(letter, x, y, vx, vy) {
    this.letter = letter;
    this.x = x;
    this.y = y;
    this.vx = vx;
    this.vy = vy;
    this.size = 30;
    this.color = getRandomColor(); // Assign random color
  }

  draw() {
    ctx.font = `${this.size}px Arial`;
    ctx.fillStyle = this.color;
    ctx.textBaseline = 'middle';
    ctx.textAlign = 'center';
    ctx.fillText(this.letter, this.x, this.y);
  }

  update() {
    this.x += this.vx;
    this.y += this.vy;

    // Bounce off edges
    if (this.x < this.size / 2 || this.x > canvas.width - this.size / 2) {
      this.vx = -this.vx;
    }
    if (this.y < this.size / 2 || this.y > canvas.height - this.size / 2) {
      this.vy = -this.vy;
    }
  }
}

// === Spawn a New Letter ===
function spawnLetter() {
  if (letters.length >= maxLetters) return;

  const letter = getRandomLetter();
  const x = Math.random() * (canvas.width - 60) + 30;
  const y = Math.random() * (canvas.height - 60) + 30;
  const vx = (Math.random() * 2 + 1) * (Math.random() < 0.5 ? 1 : -1);
  const vy = (Math.random() * 2 + 1) * (Math.random() < 0.5 ? 1 : -1);

  letters.push(new FlyingLetter(letter, x, y, vx, vy));
}

// === Get Random Letter A-Z ===
function getRandomLetter() {
  const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  return letters.charAt(Math.floor(Math.random() * letters.length));
}

// === Get Random Color ===
function getRandomColor() {
  const colors = [
    '#21c55d', // green
    '#61dafb', // blue
    '#facc15', // yellow
    '#ef4444', // red
    '#a855f7', // purple
    '#f97316', // orange
    '#14b8a6'  // teal
  ];
  return colors[Math.floor(Math.random() * colors.length)];
}

// === Game Loop ===
function gameLoop() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  for (let letterObj of letters) {
    letterObj.update();
    letterObj.draw();
  }

  requestAnimationFrame(gameLoop);
}

// === Key Press Event ===
window.addEventListener('keydown', (e) => {
  const pressed = e.key.toUpperCase();

  for (let i = 0; i < letters.length; i++) {
    if (letters[i].letter === pressed) {
      letters.splice(i, 1); // Remove letter
      score++;
      updateScore();
      break;
    }
  }
});

// === Update Score Display ===
function updateScore() {
  scoreEl.textContent = score;
}

// === Restart Game ===
function restartGame() {
  score = 0;
  letters.length = 0;
  updateScore();
}

// === Button Click Restart ===
restartBtn.addEventListener('click', () => {
  restartGame();
});

// === Letter Spawner Timer ===
let spawnTimer = setInterval(spawnLetter, spawnInterval);

// === Start Game ===
restartGame();
gameLoop();
