# games/forms.py
from django import forms
from .models import HighScore, Game


class HighScoreForm(forms.ModelForm):
    class Meta:
        model = HighScore
        fields = ['game', 'score']
        widgets = {
            'game': forms.Select(),
            'score': forms.NumberInput(attrs={'min': 0}),
        }
