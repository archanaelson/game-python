from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static
app_name = 'games'

urlpatterns = [
    path('', views.game_list, name='game_list'),
    path('description/', views.game_description, name='game_description'),
    path('score/', views.game_score, name='game_score'),
    path('<int:game_id>/', views.game_detail, name='game_detail'),
    path('submit_score/', views.submit_score, name='submit_score'),
  
    # path('game/<int:game_id>/review/', views.add_review, name='add_review'),
]
if settings.DEBUG:
    urlpatterns +=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)