@echo off
REM
cd /e "F:\SHALINI CCS\tictactoe_project"

REM
echo Starting Django server
start "" python manage.py runserver
timeout /t 3
start "" http://127.0.0.1:8000/
exit