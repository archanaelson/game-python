from django.db import models
from django.contrib.auth.models import User

class GameProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    # Add more custom fields as needed:
    bio = models.TextField(blank=True)
    avatar = models.ImageField(upload_to='avatars/', blank=True, null=True)
    high_score = models.IntegerField(default=0)

    def __str__(self):
        return self.user.username


