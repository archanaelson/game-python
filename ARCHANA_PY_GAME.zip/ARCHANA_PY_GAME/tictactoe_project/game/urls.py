from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('new/', views.new_game, name='new_game'),
    path('<int:game_id>/', views.game_play, name='game_play'),
    path('<int:game_id>/move/', views.make_move, name='make_move'),
    path('<int:game_id>/status/', views.game_status, name='game_status'),
    path('scores/', views.score_list, name='score_list'),
]
