def check_winner(board_str):
    """
    board_str: string of length 9, with characters 'X', 'O', or '-'
    Returns:
      'X' or 'O' if there is a winner,
      'D' if draw,
      None if game not finished yet.
    """
    wins = [
        (0,1,2), (3,4,5), (6,7,8),
        (0,3,6), (1,4,7), (2,5,8),
        (0,4,8), (2,4,6),
    ]
    b = board_str
    for (a,b_,c) in wins:
        if b[a] != '-' and b[a] == b[b_] == b[c]:
            return b[a]
    if '-' not in b:
        return 'D'
    return None
