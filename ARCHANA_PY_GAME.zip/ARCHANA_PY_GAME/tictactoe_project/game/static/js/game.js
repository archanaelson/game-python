
  let board = ["", "", "", "", "", "", "", "", ""];
  let nextTurn = "X";
  let gameOver = false;

  function checkWinner() {
    const wins = [
      [0,1,2], [3,4,5], [6,7,8], // rows
      [0,3,6], [1,4,7], [2,5,8], // cols
      [0,4,8], [2,4,6]          // diagonals
    ];

    for (const [a,b,c] of wins) {
      if (board[a] && board[a] === board[b] && board[a] === board[c]) {
        return board[a];
      }
    }

    if (board.every(cell => cell !== "")) {
      return "D"; // Draw
    }

    return null;
  }

  function updateStatus() {
    const statusEl = document.getElementById('status');
    const nextEl = document.getElementById('next-turn');
    const winner = checkWinner();

    if (winner === "X" || winner === "O") {
      statusEl.textContent = `Game Over — Winner is ${winner}!`;
      gameOver = true;
      disableAllCells();
    } else if (winner === "D") {
      statusEl.textContent = "Game Over — It’s a Draw.";
      gameOver = true;
      disableAllCells();
    } else {
      statusEl.textContent = "";
      nextEl.textContent = nextTurn;
    }
  }

  function disableAllCells() {
    document.querySelectorAll('#board td').forEach(cell => {
      cell.classList.add('disabled');
    });
  }

  function cellClick(e) {
    if (gameOver) return;
    const cell = e.target;
    const pos = parseInt(cell.getAttribute('data-pos'), 10);
    if (board[pos] !== "") return;

    board[pos] = nextTurn;
    cell.textContent = nextTurn;

    nextTurn = nextTurn === "X" ? "O" : "X";
    updateStatus();
  }

  document.querySelectorAll('#board td').forEach(cell => {
    cell.addEventListener('click', cellClick);
  });


