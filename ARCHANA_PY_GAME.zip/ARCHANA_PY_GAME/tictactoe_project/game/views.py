from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse
from .models import Game, GameScore
from .utils import check_winner
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.contrib.auth.models import User 
def index(request):
    players = User.objects.all()
    games = Game.objects.all()
    return render(request, 'game/index.html', {
        'players': players,
        'games': games,
    })


def new_game(request):
    if request.method == 'POST':
        px = request.POST.get('player_x')
        po = request.POST.get('player_o')
        if px == po:
            return render(request, 'game/new_game.html', {
                'players': User.objects.all(),
                'error': "Select two different players."
            })
        player_x = get_object_or_404(User, id=px)
        player_o = get_object_or_404(User, id=po)
        game = Game.objects.create(player_x=player_x, player_o=player_o)
        return redirect('game_play', game_id=game.id)
    return render(request, 'game/new_game.html', {
        'players': User.objects.all(),
    })


def game_play(request, game_id):
    game = get_object_or_404(Game, id=game_id)
    board_state = list(game.board_state)
    board = []
    for i in range(3):
        row = []
        for j in range(3):
            idx = i * 3 + j
            row.append((idx, board_state[idx]))
        board.append(row)
    return render(request, 'game/game_play.html', {
        'game': game,
        'board': board,
    })


@require_http_methods(["POST"])
def make_move(request, game_id):
    game = get_object_or_404(Game, id=game_id)
    pos = request.POST.get('position')
    player = request.POST.get('player')

    # Validate
    try:
        pos = int(pos)
    except (TypeError, ValueError):
        return JsonResponse({'error': 'Invalid position.'})

    if game.winner:
        return JsonResponse({'error': 'Game already finished.'})

    if player != game.next_turn:
        return JsonResponse({'error': 'Not your turn.'})

    if pos < 0 or pos > 8:
        return JsonResponse({'error': 'Position out of range.'})

    if game.board_state[pos] != '-':
        return JsonResponse({'error': 'Position already taken.'})

    board_list = list(game.board_state)
    board_list[pos] = player
    new_board = ''.join(board_list)
    winner = check_winner(new_board)

    game.board_state = new_board
    if winner:
        game.winner = winner
        # record score only if not already recorded
        if not hasattr(game, 'gamescore'):
            GameScore.objects.create(game=game, winner=winner)
    else:
        game.next_turn = 'O' if player == 'X' else 'X'
    game.save()

    return JsonResponse({
        'board': game.board_state,
        'next_turn': game.next_turn,
        'winner': game.winner,
    })


def game_status(request, game_id):
    game = get_object_or_404(Game, id=game_id)
    return JsonResponse({
        'board': game.board_state,
        'next_turn': game.next_turn,
        'winner': game.winner,
    })


def score_list(request):
    scores = GameScore.objects.select_related('game').order_by('-score_recorded_at')
    return render(request, 'game/scores.html', {
        'scores': scores,
    })
