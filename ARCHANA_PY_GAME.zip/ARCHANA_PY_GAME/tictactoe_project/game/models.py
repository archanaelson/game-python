from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User 



class Game(models.Model):
    player_x = models.ForeignKey(User, on_delete=models.CASCADE, related_name='games_as_x')
    player_o = models.ForeignKey(User, on_delete=models.CASCADE, related_name='games_as_o')
    board_state = models.CharField(max_length=9, default='---------' )
    next_turn = models.CharField(max_length=1, choices=[('X','X'),('O','O')], default='X')
    winner = models.CharField(max_length=1, choices=[('X','X'),('O','O'),('D','Draw')], null=True, blank=True)

    def __str__(self):
        return f"Game {self.id} ({self.player_x} vs {self.player_o})"


class GameScore(models.Model):
    game = models.OneToOneField(Game, on_delete=models.CASCADE)
    winner = models.CharField(max_length=1)  # 'X', 'O', or 'D'
    score_recorded_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"Score for Game {self.game.id}: Winner — {self.winner}"
